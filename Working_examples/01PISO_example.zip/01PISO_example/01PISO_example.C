/*---------------------------------------------------------------------------*\
     ██╗████████╗██╗  ██╗ █████╗  ██████╗ █████╗       ███████╗██╗   ██╗
     ██║╚══██╔══╝██║  ██║██╔══██╗██╔════╝██╔══██╗      ██╔════╝██║   ██║
     ██║   ██║   ███████║███████║██║     ███████║█████╗█████╗  ██║   ██║
     ██║   ██║   ██╔══██║██╔══██║██║     ██╔══██║╚════╝██╔══╝  ╚██╗ ██╔╝
     ██║   ██║   ██║  ██║██║  ██║╚██████╗██║  ██║      ██║      ╚████╔╝
     ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝      ╚═╝       ╚═══╝

 * In real Time Highly Advanced Computational Applications for Finite Volumes
 * Copyright (C) 2017 by the ITHACA-FV authors
-------------------------------------------------------------------------------
License
    This file is part of ITHACA-FV
    ITHACA-FV is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ITHACA-FV is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU Lesser General Public License for more details.
    You should have received a copy of the GNU Lesser General Public License
    along with ITHACA-FV. If not, see <http://www.gnu.org/licenses/>.
Description
    Example of steady NS Reduction Problem
SourceFiles
    03steadyNS.C
\*---------------------------------------------------------------------------*/

#include "steadyNS.H"
#include "ITHACAstream.H"
#include "ITHACAPOD.H"
#include "reducedSteadyNS.H"
#include "forces.H"
#include "IOmanip.H"


class working01 : public steadyNS
{
public:
    /// Constructor
    explicit working01(int argc, char* argv[])
        :
        steadyNS(argc, argv),
        U(_U()),
        p(_p()),
        phi(_phi())
    {}

    /// Velocity field
    volVectorField& U;
    /// Pressure field
    volScalarField& p;

    /// Flux
    surfaceScalarField& phi;


    fvVectorMatrix* Ueqn_global;
    fvScalarMatrix* Peqn_global;

    PtrList<fvVectorMatrix> UmatrixList;
    PtrList<fvScalarMatrix> PmatrixList;


    fvVectorMatrix get_Umatrix(volVectorField& U, volScalarField& p)
    {
        IOMRFZoneList& MRF = _MRF();
        surfaceScalarField& phi = _phi();
        fv::options& fvOptions = _fvOptions();
        MRF.correctBoundaryVelocity(U);

        fvVectorMatrix Ueqn
        (
            fvm::div(phi, U)
            + MRF.DDt(U)
            + turbulence->divDevReff(U)
            ==
            fvOptions(U)
        );
        Ueqn.relax();
        fvOptions.constrain(Ueqn);

        Ueqn_global = &Ueqn;
        return Ueqn;
    }

    fvScalarMatrix get_Pmatrix(volVectorField& U, volScalarField& p, scalar& presidual)
    {
        IOMRFZoneList& MRF = _MRF();
        surfaceScalarField& phi = _phi();
        simpleControl& simple = _simple();
        fv::options& fvOptions = _fvOptions();
        MRF.correctBoundaryVelocity(U);
        fvMesh& mesh = _mesh();

        volScalarField rAU(1.0 / Ueqn_global->A());
        volVectorField HbyA(constrainHbyA(rAU * Ueqn_global->H(), U, p));
        surfaceScalarField phiHbyA("phiHbyA", fvc::flux(HbyA));
        MRF.makeRelative(phiHbyA);
        adjustPhi(phiHbyA, U, p);

        tmp<volScalarField> rAtU(rAU);
        if (simple.consistent())
        {
            rAtU = 1.0 / (1.0 / rAU - Ueqn_global->H1());
            phiHbyA +=
                fvc::interpolate(rAtU() - rAU) * fvc::snGrad(p) * mesh.magSf();
            HbyA -= (rAU - rAtU()) * fvc::grad(p);
        }

        constrainPressure(p, U, phiHbyA, rAtU(), MRF);
        int i = 0;

        while (simple.correctNonOrthogonal())
        {
            fvScalarMatrix pEqn
            (
                fvm::laplacian(rAtU(), p) == fvc::div(phiHbyA)
            );
            pEqn.setReference(pRefCell, pRefValue);

            if (i == 0)
            {
                presidual = pEqn.solve().initialResidual();
            }
            else
            {
                pEqn.solve().initialResidual();
            }
            if (simple.finalNonOrthogonalIter())
            {
                phi = phiHbyA - pEqn.flux();
            }
            i++;
        }

        p.relax();
        U = HbyA - rAtU() * fvc::grad(p);
        U.correctBoundaryConditions();
        fvOptions.correct(U);

        fvScalarMatrix pEqn
        (
            fvm::laplacian(rAtU(), p) == fvc::div(phiHbyA)
        );
        return pEqn;
        /*return *pEqnLoc;*/
    }

    void offlineSolve2()
    {
        Vector<double> inl(0, 0, 0);
        List<scalar> mu_now(1);
        Vector<double> Uinl(0, 0, 0);
        label BCind = 0;
        simpleControl& simple = _simple();
        Time& runTime = _runTime();
        singlePhaseTransportModel& laminarTransport = _laminarTransport();
        fv::options& fvOptions = _fvOptions();

        for (label i = 0; i < mu.cols(); i++)
        {
            turbulence->read();
            mu_now[0] = mu(0, i);
            change_viscosity(mu(0, i));
            assignIF(U, Uinl);
            scalar residual = 1;
            scalar uresidual = 1;
            Vector<double> uresidual_v(0, 0, 0);
            scalar presidual = 1;
            scalar csolve = 0;

#if OFVER == 6
            while (simple.loop(runTime) && residual > tolerance && csolve < maxIter )
#else
            while (simple.loop() && residual > tolerance && csolve < maxIter )
#endif
            {
                fvVectorMatrix UEqn(get_Umatrix(U, p));
                if (simple.momentumPredictor())
                {
                    Vector<double> uresidual_v = solve(UEqn == -fvc::grad(p)).initialResidual();
                    fvOptions.correct(U);

                    scalar C = 0;

                    for (label i = 0; i < 3; i++)
                    {
                        if (C < uresidual_v[i])
                        {
                            C = uresidual_v[i];
                        }
                    }
                    uresidual = C;
                }
                get_Pmatrix(U, p, presidual);
                residual = max(presidual, uresidual);

                Info << "Time = " << runTime.timeName() << nl << endl;
                laminarTransport.correct();
                turbulence->correct();
            }
            runTime.setTime(runTime.startTime(), 0);
            exit(0);
        }

    }

    /// Perform an Offline solve
    void offlineSolve()
    {
        Vector<double> inl(0, 0, 0);
        List<scalar> mu_now(1);

        // if the offline solution is already performed read the fields
        if (offline)
        {
            ITHACAstream::read_fields(Ufield, U, "./ITHACAoutput/Offline/");
            ITHACAstream::read_fields(Pfield, p, "./ITHACAoutput/Offline/");
            mu_samples =
                ITHACAstream::readMatrix("./ITHACAoutput/Offline/mu_samples_mat.txt");
        }
        else
        {
            Vector<double> Uinl(0, 0, 0);
            label BCind = 0;

            for (label i = 0; i < mu.cols(); i++)
            {
                mu_now[0] = mu(0, i);
                change_viscosity(mu(0, i));
                assignIF(U, Uinl);
                truthSolve(mu_now);
                exit(0);
            }

        }
    }

};

int main(int argc, char* argv[])
{
    // Construct the tutorial object
    working01 example(argc, argv);
    // Read some parameters from file
    ITHACAparameters para;
    int NmodesUout = para.ITHACAdict->lookupOrDefault<int>("NmodesUout", 15);
    int NmodesPout = para.ITHACAdict->lookupOrDefault<int>("NmodesPout", 15);
    int NmodesSUPout = para.ITHACAdict->lookupOrDefault<int>("NmodesSUPout", 15);
    int NmodesUproj = para.ITHACAdict->lookupOrDefault<int>("NmodesUproj", 10);
    int NmodesPproj = para.ITHACAdict->lookupOrDefault<int>("NmodesPproj", 10);
    int NmodesSUPproj = para.ITHACAdict->lookupOrDefault<int>("NmodesSUPproj", 10);
    // Read the par file where the parameters are stored
    word filename("./par");
    example.mu = ITHACAstream::readMatrix(filename);
    // Set the inlet boundaries patch 0 directions x and y
    example.inletIndex.resize(1, 2);
    example.inletIndex(0, 0) = 0;
    example.inletIndex(0, 1) = 0;
    // Perform the offline solve
    example.offlineSolve2();
    exit(0);

    // example.offlineSolve();
    // Solve the supremizer problem
    example.solvesupremizer();
    ITHACAstream::read_fields(example.liftfield, example.U, "./lift/");
    // Homogenize the snapshots
    example.computeLift(example.Ufield, example.liftfield, example.Uomfield);
    // Perform POD on velocity pressure and supremizers and store the first 10 modes
    ITHACAPOD::getModes(example.Uomfield, example.Umodes, example.podex, 0, 0,
                        NmodesUout);
    ITHACAPOD::getModes(example.Pfield, example.Pmodes, example.podex, 0, 0,
                        NmodesPout);
    ITHACAPOD::getModes(example.supfield, example.supmodes, example.podex,
                        example.supex, 1, NmodesSUPout);
    // Perform the Galerkin Projection
    example.projectSUP("./Matrices", NmodesUproj, NmodesPproj, NmodesSUPproj);
    // Create the reduced object
    reducedSteadyNS ridotto(example);
    // Set the inlet velocity
    Eigen::MatrixXd vel_now(2, 1);
    vel_now(0, 0) = 1;
    vel_now(1, 0) = 0;

    // Perform an online solve for the new values of inlet velocities
    for (label k = 0; k < 20; k++)
    {
        // Set the reduced viscosity
        ridotto.nu = example.mu(k, 0);
        ridotto.solveOnline_sup(vel_now);
        Eigen::MatrixXd tmp_sol(ridotto.y.rows() + 1, 1);
        tmp_sol(0) = k + 1;
        tmp_sol.col(0).tail(ridotto.y.rows()) = ridotto.y;
        ridotto.online_solution.append(tmp_sol);
    }

    // Save the online solution
    ITHACAstream::exportMatrix(ridotto.online_solution, "red_coeff", "python",
                               "./ITHACAoutput/red_coeff");
    ITHACAstream::exportMatrix(ridotto.online_solution, "red_coeff", "matlab",
                               "./ITHACAoutput/red_coeff");
    ITHACAstream::exportMatrix(ridotto.online_solution, "red_coeff", "eigen",
                               "./ITHACAoutput/red_coeff");
    // Reconstruct and export the solution
    ridotto.reconstruct_sup("./ITHACAoutput/Reconstruction/");
    exit(0);
}